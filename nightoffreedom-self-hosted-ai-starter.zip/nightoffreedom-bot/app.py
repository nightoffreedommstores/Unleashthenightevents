import os, sqlite3, secrets
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, redirect, url_for, session, render_template, jsonify, flash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('DATABASE_PATH', os.path.join(APP_DIR, 'bot.db'))
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['MAX_CONTENT_LENGTH'] = 1 * 1024 * 1024

OPENING = ("Step into a bold new experience with us where you’re free to explore your desires, "
           "connect with your authentic self, and feel fully empowered in a safe, respectful, "
           "and inclusive space. We’d love to get to know you better. What’s your name and "
           "which area are you located in?")
AFTER_DETAILS = ("Night of Freedom is a private, adults-only social experience for open-minded singles "
                 "and couples who enjoy meeting new people, connecting, dressing up, and enjoying a "
                 "discreet and respectful atmosphere. Our events are designed around privacy, mutual "
                 "respect, personal boundaries, and consent. Guests are expected to respect other "
                 "attendees and the event guidelines at all times. Before I continue with the event "
                 "details, please take a moment to review and agree to our rules and terms. Does "
                 "everything sound good? Do you agree to the rules and terms above? Reply with ‘YES’ "
                 "or let me know if you have any questions.")
DEFAULT_KNOWLEDGE = f"""BRAND: Unleash the Night Events. Event experience: Night of Freedom.
REQUIRED FIRST RESPONSE:
{OPENING}
FLOW:
- Treat greetings, interest, and requests for more information as a new-conversation opening; do not use a generic 'How can I help?' fallback.
- Recognize a customer's name and area/city/state/country from natural language. Do not require exact phrasing.
- If only a name is supplied, say: Nice to meet you. What area are you located in?
- If only a location is supplied, say: Thanks. And what name would you like me to use?
- After both name and area are available, thank them by name and use this approved message:
{AFTER_DETAILS}
- Wait for YES / questions before moving to any later stage. Do not jump directly to ticket prices or payment.
AGE, PRIVACY, CONSENT:
- All listed events are strictly 18+. Never imply minors may attend.
- Emphasize mutual respect, consent, personal boundaries, privacy, and event rules.
- Do not promise absolute secrecy or unsupported safety guarantees. Do not ask for unnecessary sensitive information or infer exact location.
CURRENT EVENT REFERENCE (verify before using because dates may change):
- 23–25 October 2026 — Halloween
- 29–31 October 2026 — Halloween
- Historical dates in source material: 25–28 September 2026 and 6–8 October 2026 — Sweet Temptations. Do not present these as upcoming.
- One valid ticket covers listed event dates according to applicable ticket terms. Do not invent dates, venues, prices, availability, ticket conditions, refund decisions, or payment instructions.
HANDOFF:
- If a customer asks for a human, requests a refund/financial decision, or asks anything not covered by approved knowledge, stop guessing and request human assistance.
- Do not invent event venue/address, prices, availability, refund rules, or payment links. Never pressure a customer.
"""

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, channel TEXT NOT NULL, customer TEXT NOT NULL, incoming TEXT NOT NULL, reply TEXT NOT NULL, handoff INTEGER NOT NULL DEFAULT 0)')
        c.execute('CREATE TABLE IF NOT EXISTS contacts (customer TEXT PRIMARY KEY, name TEXT, area TEXT, updated_at TEXT NOT NULL)')
        c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)', ('knowledge', DEFAULT_KNOWLEDGE))
        c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)', ('bot_enabled', '1'))

def setting(key, default=''):
    with db() as c:
        row = c.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return row['value'] if row else default

def set_setting(key, value):
    with db() as c:
        c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, value))

def logged_in():
    return bool(session.get('logged_in'))

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not logged_in(): return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)
    return wrapped

def safe_rule_reply(message, customer='Customer'):
    """Deterministic safe fallback; no WhatsApp transport is connected in this starter."""
    msg = (message or '').strip()
    low = msg.lower()
    if not msg:
        return 'Please send a message so I can help.', False, None, None
    human_terms = ['human', 'real person', 'agent', 'someone from your team', 'speak to someone', 'refund', 'chargeback']
    if any(term in low for term in human_terms):
        return 'I’ll ask a team member to review this and respond personally. I don’t want to guess or give you incorrect information.', True, None, None
    if any(x in low for x in ['yes', 'i agree', 'agree to the rules', 'sounds good']) and len(low) < 120:
        return 'Thank you for confirming. A team member can share the next approved event details. I won’t guess ticket prices, venue details, availability, or payment instructions.', True, None, None
    # Simple extraction is intentionally conservative; the AI provider can improve this when configured.
    import re
    name = None; area = None
    patterns = [r"\bmy name is ([A-Z][a-zA-Z'-]+)\b", r"\bi am ([A-Z][a-zA-Z'-]+)\b", r"\bi'm ([A-Z][a-zA-Z'-]+)\b", r"\bname is ([A-Z][a-zA-Z'-]+)\b"]
    for pat in patterns:
        m = re.search(pat, msg, re.I)
        if m and m.group(1).lower() not in {'interested','curious','located','in'}:
            name = m.group(1).strip().title(); break
    loc = re.search(r"\b(?:from|in|located in|based in)\s+([A-Z][A-Za-z .'-]{1,40})(?:[,.!?]|$)", msg)
    if loc:
        area = loc.group(1).strip().rstrip('.!?').title()
    if name and area:
        with db() as c:
            c.execute('INSERT INTO contacts(customer,name,area,updated_at) VALUES(?,?,?,?) ON CONFLICT(customer) DO UPDATE SET name=excluded.name, area=excluded.area, updated_at=excluded.updated_at', (customer, name, area, datetime.now(timezone.utc).isoformat()))
        return f'Thank you, {name}. {AFTER_DETAILS}', False, name, area
    if name:
        return 'Nice to meet you. What area are you located in?', False, name, None
    if area:
        return 'Thanks. And what name would you like me to use?', False, None, area
    if any(x in low for x in ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'how are you', 'interested', 'tell me more', 'learn more', 'night of freedom', 'what do you do']):
        return OPENING, False, None, None
    return 'I don’t want to give you incorrect information. I’ll flag this question for a team member to answer. You can also ask about our general event experience, age requirements, or participation guidelines.', True, None, None

def generate_reply(message, customer='Customer'):
    # Optional OpenAI integration. If no key/package is configured, use deterministic rules.
    api_key = os.environ.get('OPENAI_API_KEY')
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model=os.environ.get('OPENAI_MODEL', 'gpt-4.1-mini'),
                instructions=("You are the discreet, respectful customer service assistant for Unleash the Night Events / Night of Freedom. "
                    "Use only the approved knowledge below. Follow the staged flow: new greeting -> ask name and area -> after both, thank by name and present the approved event overview and rules agreement -> wait for agreement. "
                    "Never invent prices, venues, event availability, refunds, payment instructions, or facts not in knowledge. All events are 18+. Respect consent and boundaries. "
                    "If asked for a human, refund, financial decision, or something not covered, clearly say a human team member must handle it. Be concise.\n\nAPPROVED KNOWLEDGE:\n" + setting('knowledge', DEFAULT_KNOWLEDGE)),
                input=f"Customer identifier: {customer}\nCustomer message: {message}"
            )
            text = (response.output_text or '').strip()
            if text: return text, any(x in text.lower() for x in ['team member must','human team member','ask a team member']), None, None
        except Exception:
            pass
    return safe_rule_reply(message, customer)

@app.route('/health')
def health(): return jsonify(status='ok', app='Nightoffreedom Self-hosted AI Starter', whatsapp_connected=False)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        expected = os.environ.get('ADMIN_PASSWORD')
        if not expected:
            flash('Set ADMIN_PASSWORD in Railway Variables before logging in.', 'error')
        elif secrets.compare_digest(request.form.get('password',''), expected):
            session.clear(); session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else: flash('Incorrect password.', 'error')
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    with db() as c:
        total = c.execute('SELECT COUNT(*) n FROM messages').fetchone()['n']
        handoffs = c.execute('SELECT COUNT(*) n FROM messages WHERE handoff=1').fetchone()['n']
        contacts = c.execute('SELECT COUNT(*) n FROM contacts').fetchone()['n']
        messages = c.execute('SELECT * FROM messages ORDER BY id DESC LIMIT 30').fetchall()
    return render_template('dashboard.html', total=total, handoffs=handoffs, contacts=contacts, messages=messages, enabled=setting('bot_enabled','1') == '1')

@app.route('/knowledge', methods=['GET','POST'])
@login_required
def knowledge():
    if request.method == 'POST':
        value = request.form.get('knowledge','').strip()
        if not value: flash('Knowledge cannot be empty.', 'error')
        else: set_setting('knowledge', value); flash('Knowledge saved.', 'success')
        return redirect(url_for('knowledge'))
    return render_template('knowledge.html', knowledge=setting('knowledge', DEFAULT_KNOWLEDGE))

@app.route('/settings', methods=['POST'])
@login_required
def settings():
    set_setting('bot_enabled', '1' if request.form.get('bot_enabled') == '1' else '0')
    flash('Bot test mode settings saved. WhatsApp is not connected.', 'success')
    return redirect(url_for('dashboard'))

@app.route('/test', methods=['GET','POST'])
@login_required
def test_chat():
    reply = None; incoming = ''; customer = 'test-customer'
    if request.method == 'POST':
        incoming = request.form.get('message','').strip()
        customer = request.form.get('customer','test-customer').strip()[:120] or 'test-customer'
        if not incoming: flash('Enter a test message.', 'error')
        else:
            if setting('bot_enabled','1') == '1': reply, handoff, _, _ = generate_reply(incoming, customer)
            else: reply, handoff = 'Automation is paused. This is a test dashboard; no WhatsApp message was sent.', False
            with db() as c:
                c.execute('INSERT INTO messages(created_at,channel,customer,incoming,reply,handoff) VALUES(?,?,?,?,?,?)', (datetime.now(timezone.utc).isoformat(), 'dashboard-test', customer, incoming, reply, int(handoff)))
    return render_template('test.html', reply=reply, incoming=incoming, customer=customer)

@app.route('/api/test-chat', methods=['POST'])
@login_required
def api_test_chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get('message','')).strip()
    customer = str(data.get('customer','test-customer'))[:120]
    if not message: return jsonify(error='message is required'), 400
    reply, handoff, _, _ = generate_reply(message, customer)
    with db() as c:
        c.execute('INSERT INTO messages(created_at,channel,customer,incoming,reply,handoff) VALUES(?,?,?,?,?,?)', (datetime.now(timezone.utc).isoformat(), 'dashboard-api-test', customer, message, reply, int(handoff)))
    return jsonify(reply=reply, handoff=handoff, whatsapp_connected=False)

init_db()
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))
