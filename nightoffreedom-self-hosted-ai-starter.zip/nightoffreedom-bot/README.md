# Nightoffreedom Self-hosted AI Bot — starter

A small Flask admin dashboard and AI reply engine for Unleash the Night Events / Night of Freedom. This first version is deliberately **not connected to WhatsApp**. It lets you test the conversation flow, edit approved knowledge, and review test conversations before choosing any messaging connector.

## Included
- Password-protected admin dashboard
- Editable knowledge base seeded from your business AI training guide
- Test chat and recent conversation log
- Safe fallback rules if no model API key is configured
- Optional OpenAI Responses API integration through environment variables
- SQLite storage for test messages and basic contact details
- Health endpoint at `/health`

## Deploy on Railway
1. Create a new Railway project/service from this folder (GitHub repository or Railway-supported source upload).
2. Railway should detect `requirements.txt` and `Procfile`. Set the start command to `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 120` if needed.
3. Add Railway Variables:
   - `ADMIN_PASSWORD`: a long, unique password
   - `SECRET_KEY`: a long random secret
   - Optional `OPENAI_API_KEY` and `OPENAI_MODEL`
4. Deploy and open the generated domain. Log in with `ADMIN_PASSWORD`.
5. Open **Test AI** and try the suggested messages. Edit the knowledge under **Knowledge**.
6. For persistent SQLite data, attach a Railway Volume and set `DATABASE_PATH` to a path on that volume, such as `/data/bot.db`.

## Local run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export ADMIN_PASSWORD='use-a-long-password'
export SECRET_KEY='use-a-long-random-value'
python app.py
```
Then visit `http://localhost:8080`.

## Important limitations
- This project does not connect to WhatsApp, Meta Graph API, or an unofficial WhatsApp Web library.
- It cannot read/send real WhatsApp messages until a connector is deliberately designed and configured.
- Unofficial WhatsApp Web automation may violate WhatsApp terms, break when WhatsApp changes, expose session credentials, or lead to temporary/permanent number restrictions. Do not use it on your primary business number without accepting those risks and checking current terms.
- This starter is a prototype, not a production-hardened multi-user CRM. Before real customer use, add CSRF protection, rate limiting, backups, stronger authorization, audit controls, retention policies, and secure deployment review.
- Do not collect payment card details, passwords, or unnecessary sensitive personal data in chat.
- The event guide includes historical dates. Verify all event dates and approved policies before using replies with customers.
